print('--------------------------------')
print('          HELLO APP')
print('--------------------------------')
print()

user_text = input('What is your name? ')
greeting = 'Nice to meet you ' + user_text

print(greeting)
